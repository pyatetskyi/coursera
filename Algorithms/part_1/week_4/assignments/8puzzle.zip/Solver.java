/**
 * Coursera: Algorithms
 * Part 1 - Week 4: 8 Puzzle
 *
 * @author Pavlo Pyatetskyi
 */

import edu.princeton.cs.algs4.MinPQ;

import java.util.Comparator;
import java.util.Stack;

public class Solver {

    private final Stack<Board> boards;
    private int moves;
    private boolean isSolvable;

    private class SearchNode implements Comparable<SearchNode> {
        private Board board;
        private int moves;
        private SearchNode previous;
        private int cachedPriority = -1;

        SearchNode(Board board, int moves, SearchNode previous) {
            this.board = board;
            this.moves = moves;
            this.previous = previous;
        }

        private int priority() {
            if (cachedPriority == -1) {
                cachedPriority = moves + board.manhattan();
            }
            return cachedPriority;
        }

        @Override
        public int compareTo(SearchNode that) {
            if (this.priority() < that.priority()) {
                return -1;
            }
            if (this.priority() > that.priority()) {
                return +1;
            }
            return 0;
        }
    }

    /*
     * find a solution to the initial board (using the A* algorithm)
     */
    public Solver(Board initial) {
        boards = new Stack<Board>();
        if (initial.isGoal()) {
            isSolvable = true;
            this.boards.push(initial);
            return;
        }
        if (initial.twin().isGoal()) {
            isSolvable = false;
            return;
        }

        MinPQ<SearchNode> minPQ = new MinPQ<SearchNode>();
        MinPQ<SearchNode> minPQTwin = new MinPQ<SearchNode>();
        moves = 0;
        Board board = initial;
        Board boardTwin = initial.twin();
        SearchNode node = new SearchNode(board, 0, null);
        SearchNode nodeTwin = new SearchNode(boardTwin, 0, null);
        minPQ.insert(node);
        minPQTwin.insert(nodeTwin);
        while (moves < 100) {
            node = minPQ.delMin();
            nodeTwin = minPQTwin.delMin();
            board = node.board;
            boardTwin = nodeTwin.board;
            if (boardTwin.isGoal()) {
                isSolvable = false;
                return;
            }
            if (board.isGoal()) {
                isSolvable = true;
                this.boards.push(board);
                while (node.previous != null) {
                    node = node.previous;
                    this.boards.push(node.board);
                }
                return;
            }
            node.moves++;
            nodeTwin.moves++;
            Iterable<Board> neighbors = board.neighbors();
            for (Board neighbor : neighbors) {
                if (node.previous != null
                        && neighbor.equals(node.previous.board)) {
                    continue;
                }
                SearchNode newNode = new SearchNode(neighbor, node.moves, node);
                minPQ.insert(newNode);
            }
            Iterable<Board> neighborsTwin = boardTwin.neighbors();
            for (Board neighbor : neighborsTwin) {
                if (nodeTwin.previous != null
                        && neighbor.equals(nodeTwin.previous.board)) {
                    continue;
                }
                SearchNode newNode = new SearchNode(neighbor, nodeTwin.moves,
                        nodeTwin);
                minPQTwin.insert(newNode);
            }
        }
    }

    /*
     * is the initial board solvable?
     */
    public boolean isSolvable() {
        return isSolvable;
    }

    /*
     * min number of moves to solve initial board; -1 if no solution
     */
    public int moves() {
        if (isSolvable) {
            return boards.size() - 1;
        }
        else {
            return -1;
        }
    }

    /*
     * sequence of boards in a shortest solution; null if no solution
     */
    public Iterable<Board> solution() {
        if (isSolvable) {
            return boards;
        } else {
            return null;
        }
    }



    /*

    private int movesCount;
    private final Node minNode;
    // private final MinPQ<Node> pq1;
    // private final MinPQ<Node> pq2;
    private final Comparator<Node> manhattanPriority;

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        manhattanPriority = new ManhattanPriority();
        MinPQ<Node> pq1 = new MinPQ<>(manhattanPriority);
        MinPQ<Node> pq2 = new MinPQ<>(manhattanPriority);
        movesCount = 0;

        pq1.insert(new Node(initial, movesCount, null));
        pq2.insert(new Node(initial.twin(), movesCount, null));
        Node cur1;
        Node cur2;
        while (!pq1.min().board.isGoal() && !pq2.min().board.isGoal()) {
            cur1 = pq1.delMin();
            cur2 = pq2.delMin();
            for (Board board : cur1.board.neighbors()) {
                if (null != cur1.prev && board.equals(cur1.prev.board)) {
                    continue;
                }
                pq1.insert(new Node(board, cur1.moves + 1, cur1));
            }
            for (Board board : cur2.board.neighbors()) {
                if (null != cur2.prev && board.equals(cur2.prev.board)) {
                    continue;
                }
                pq2.insert(new Node(board, cur2.moves + 1, cur2));
            }
        }
        if (!pq1.min().board.isGoal()) {
            movesCount = -1;
        }
        else {
            movesCount = pq1.min().moves;
        }

        minNode = pq1.min();
    }

    // is the initial board solvable?
    public boolean isSolvable() {
        return movesCount != -1;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        return movesCount;
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        if (!isSolvable()) {
            return null;
        }
        Stack<Board> stack = new Stack<>();
        Node path = minNode;
        while (path != null) {
            stack.push(path.board);
            path = path.prev;
        }
        return stack;
    }

    private class Node {
        private final Board board;
        private final int moves;
        private final Node prev;

        public Node(Board board, int moves, Node prev) {
            this.board = board;
            this.moves = moves;
            this.prev = prev;
        }
    }

    private class ManhattanPriority implements Comparator<Node> {
        @Override
        public int compare(Node o1, Node o2) {

            int num1 = o1.board.manhattan() + o1.moves;
            int num2 = o2.board.manhattan() + o2.moves;
            if (num1 == num2) {
                if (o1.board.hamming() == o2.board.hamming()) {
                    return 0;
                }
                else if (o1.board.hamming() < o2.board.hamming()) {
                    return -1;
                }
                else {
                    return 1;
                }
            }
            else if (num1 < num2) {
                return -1;
            }
            else {
                return 1;
            }

            // return o1.board.manhattan() - o2.board.manhattan();

        }

    }

    */

}
